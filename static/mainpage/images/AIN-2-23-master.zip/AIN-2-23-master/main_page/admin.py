from django.contrib import admin
from .models import StringRun,FilmModel,AfishaTable,Slider

admin.site.register(StringRun)
admin.site.register(FilmModel)
admin.site.register(AfishaTable)
admin.site.register(Slider)